/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import com.itextpdf.io.image.ImageData;
import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.io.image.ImageType;
import com.itextpdf.kernel.color.Color;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Image;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.property.TextAlignment;

import java.io.IOException;
import java.net.URL;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Escinf
 */
@WebServlet(name = "PdfServlet", urlPatterns = {"/PdfServlet"})
public class PdfServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("aplication/pdf");
        response.setHeader("Content-Disposition", "inline;filename=\"report.pdf\"");
        PdfDocument pdf = new PdfDocument(new PdfWriter(response.getOutputStream()));
        Document document = new Document(pdf);
        
        Paragraph p;
        
        p = new Paragraph("TIQUETE DE VUELO");
        p.setTextAlignment(TextAlignment.CENTER);
        p.setBold();
        p.setBackgroundColor(Color.PINK);
        document.add(p);

        p = new Paragraph("Vuelo 1060, San Jose - Miami, 05 de Junio del 2017 ");
        p.setTextAlignment(TextAlignment.LEFT);
        p.setBold();
        document.add(p);
        
        Image img = new Image(ImageDataFactory.create(this.getServletContext().getResource("/images/Reporte.png")));
        document.add(img);
        
        p = new Paragraph("------------- \n"+
                "Juan Perez (asiento 14A) \n"+
                "Maria Perez (asiento 14B) \n"+
                "Juansillo Perez (asiento 14C) \n"+
                "Mariquita Perez (asiento 14D) \n"+ 
                "------------- ");
        document.add(p);

        p = new Paragraph("COSTO TOTAL: $1320 ");
        p.setTextAlignment(TextAlignment.RIGHT);
        p.setBold();
        p.setBackgroundColor(Color.PINK);
        document.add(p);
        
        document.close();
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
