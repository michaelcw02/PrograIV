/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import java.io.StringReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

/**
 *
 * @author Escinf
 */
public class TipoCambioProxy {

    private static String obtenerIndicadoresEconomicosXML(java.lang.String tcIndicador, java.lang.String tcFechaInicio, java.lang.String tcFechaFinal, java.lang.String tcNombre, java.lang.String tnSubNiveles) {
        cr.fi.bccr.sdde.ws.WsIndicadoresEconomicos service = new cr.fi.bccr.sdde.ws.WsIndicadoresEconomicos();
        cr.fi.bccr.sdde.ws.WsIndicadoresEconomicosSoap port = service.getWsIndicadoresEconomicosSoap();
        return port.obtenerIndicadoresEconomicosXML(tcIndicador, tcFechaInicio, tcFechaFinal, tcNombre, tnSubNiveles);
    }
    
    public static double dolarHoy(){
        Element rootElement;
        Date d = new java.util.Date();
        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        String hoy=df.format(d);
        String xml= obtenerIndicadoresEconomicosXML("318", hoy, hoy, "UNA", "N");
        try{
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(new InputSource(new StringReader(xml)));
            rootElement = document.getDocumentElement();
            String cambioStr= getValue(rootElement, "NUM_VALOR");
            return Double.parseDouble(cambioStr);
        }
        catch(Exception e){
            return 0f;
        }  
    }
    
 public static String getValue(Element rootElement, String tag){
    try {
      NodeList list =rootElement.getElementsByTagName(tag);
      if (list != null && list.getLength() > 0) {
          NodeList subList = list.item(0).getChildNodes();
          if (subList != null && subList.getLength() > 0) {
              return subList.item(0).getNodeValue();
          }
      } 
    } catch (Exception e) {
      return "0";
    }
    return "0";
}    
}
