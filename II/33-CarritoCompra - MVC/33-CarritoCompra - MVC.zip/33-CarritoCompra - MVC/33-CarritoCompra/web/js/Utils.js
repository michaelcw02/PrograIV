get = function(id){
    return document.getElementById(id).value;
};

set = function(id,value){
    document.getElementById(id).value=value;
};